package crimeManagementSystem;

public class AddTeam {
private int id;
private String nameofteam,leadingofficername,officeaddress,email,selectteammembers;

public String getSelectteammembers() {
	return selectteammembers;
}
public void setSelectteammembers(String selectteammembers) {
	this.selectteammembers = selectteammembers;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getNameofteam() {
	return nameofteam;
}
public void setNameofteam(String nameofteam) {
	this.nameofteam = nameofteam;
}
public String getLeadingofficername() {
	return leadingofficername;
}
public void setLeadingofficername(String leadingofficername) {
	this.leadingofficername = leadingofficername;
}
public String getOfficeaddress() {
	return officeaddress;
}
public void setOfficeaddress(String officeaddress) {
	this.officeaddress = officeaddress;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}


}




