package crimeManagementSystem;

public class SignUp {

	private int id;

private String fullname,email,address,gender,password,cpassword,phone,answerthesecurityquestions,selectsecurityquestion;

public String getSelectsecurityquestion() {
	return selectsecurityquestion;
}

public void setSelectsecurityquestion(String selectsecurityquestion) {
	this.selectsecurityquestion = selectsecurityquestion;
}

private int pennumber;

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getFullname() {
	return fullname;
}

public void setFullname(String fullname) {
	this.fullname = fullname;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getCpassword() {
	return cpassword;
}

public void setCpassword(String cpassword) {
	this.cpassword = cpassword;
}

public String getPhone() {
	return phone;
}

public void setPhone(String phone) {
	this.phone = phone;
}



public String getAnswerthesecurityquestions() {
	return answerthesecurityquestions;
}

public void setAnswerthesecurityquestions(String answerthesecurityquestions) {
	this.answerthesecurityquestions = answerthesecurityquestions;
}

public int getPennumber() {
	return pennumber;
}

public void setPennumber(int pennumber) {
	this.pennumber = pennumber;
}


}


